"""
FirmwareFinder — Config Service
==================================
Central access to all application settings stored in SQLite.
Provides typed getters/setters with defaults.
"""

import os
import sys

from app.infrastructure.database import Database

# ── App paths ──────────────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    _BASE = os.path.dirname(sys.executable)
else:
    _BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

APP_DATA         = os.path.join(os.environ.get('LOCALAPPDATA', _BASE), 'FirmwareFinder')
DB_PATH          = os.path.join(APP_DATA, 'firmware_finder.db')
LOCAL_FW         = os.path.join(APP_DATA, 'firmware')
LOCAL_TEMPLATES  = os.path.join(APP_DATA, 'templates')
SYNC_LOG         = os.path.join(APP_DATA, 'sync.log')

os.makedirs(APP_DATA, exist_ok=True)
os.makedirs(LOCAL_FW, exist_ok=True)
os.makedirs(LOCAL_TEMPLATES, exist_ok=True)

# ── Defaults ──────────────────────────────────────────────────────────────────
DEFAULTS = {
    'root_path':           '',
    'protocol_folder':     '',
    'admin_password':      '12345',
    'programmer_password': '',
    'current_role':        'naladchik',
    'theme':               'light',          # light | dark
    'keep_archives':       'false',
    'image_server_port':   '9876',
    'auto_cleanup_minutes': '0',
    # Version prefix map — stored as JSON
    'version_prefixes':    '{"ТГР":"5","ПЖ":"4","КПЧ":"3","ПЧ":"2","КНС":"1"}',
    # Combobox option lists — stored as JSON arrays
    'equipment_types':     '["НГР","ПЖ","ТГР","ШУЗ","КНС","КПЧ","БНС","ФНС","ОПЦ","Другое"]',
    'work_types':          '["","ПП","УПП","ПЧ","КПЧ"]',
    'controller_types':    '["","SMH4","SMH5","SMH2010","SMH","KINCO","MK070","PIXEL","FORTUS"]',
    'quick_apps':          '[]',
}

import json


class ConfigService:
    """Typed settings access backed by SQLite settings table."""

    def __init__(self, db: Database):
        self._db = db

    # ── Generic ───────────────────────────────────────────────────────────────

    def get(self, key: str) -> str:
        return self._db.get_setting(key, DEFAULTS.get(key, ''))

    def set(self, key: str, value: str):
        self._db.set_setting(key, value)

    # ── Typed accessors ───────────────────────────────────────────────────────

    def root_path(self) -> str:
        return self.get('root_path')

    def set_root_path(self, path: str):
        self.set('root_path', path)

    def protocol_folder(self) -> str:
        return self.get('protocol_folder')

    def admin_password(self) -> str:
        return self.get('admin_password')

    def programmer_password(self) -> str:
        return self.get('programmer_password')

    def current_role(self) -> str:
        return self.get('current_role')

    def set_role(self, role: str):
        self.set('current_role', role)

    def theme(self) -> str:
        return self.get('theme')

    def set_theme(self, theme: str):
        self.set('theme', theme)

    def keep_archives(self) -> bool:
        return self.get('keep_archives').lower() == 'true'

    def version_prefixes(self) -> dict[str, str]:
        try:
            return json.loads(self.get('version_prefixes'))
        except Exception:
            return {}

    def equipment_types(self) -> list[str]:
        try:
            return json.loads(self.get('equipment_types'))
        except Exception:
            return []

    def work_types(self) -> list[str]:
        try:
            return json.loads(self.get('work_types'))
        except Exception:
            return []

    def controller_types(self) -> list[str]:
        try:
            return json.loads(self.get('controller_types'))
        except Exception:
            return []

    def quick_apps(self) -> list[dict]:
        try:
            return json.loads(self.get('quick_apps'))
        except Exception:
            return []

    def set_quick_apps(self, apps: list[dict]):
        self.set('quick_apps', json.dumps(apps, ensure_ascii=False))

    def image_server_port(self) -> int:
        try:
            return int(self.get('image_server_port'))
        except Exception:
            return 9876
