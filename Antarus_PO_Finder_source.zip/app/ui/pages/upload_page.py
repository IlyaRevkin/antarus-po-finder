"""
FirmwareFinder — Upload Page
================================
Drag-and-drop firmware upload for programmers.
Auto-detects metadata, validates version, records to DB.
"""

import os
import json
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QComboBox, QTextEdit, QPushButton,
    QListWidget, QListWidgetItem, QMessageBox, QGroupBox,
    QSizePolicy, QAbstractItemView, QFrame, QScrollArea, QFileDialog, QDialog,
)
from PySide6.QtCore import Qt, Signal, QSize
from app.ui.icons import make_icon, ICON_SECONDARY, ICON_ON_ACCENT

from app.domain.exceptions import VersionConflictError, InvalidVersionError, FileOperationError
from app.ui.widgets.drop_zone import DropZone, PathDropEdit, MiniDropZone


class UploadPage(QWidget):
    def __init__(self, main_win):
        super().__init__()
        self._mw = main_win
        self._src_path = ''
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 16)
        layout.setSpacing(16)

        # ── Title ─────────────────────────────────────────────────────────────
        title = QLabel('Загрузка прошивки')
        title.setObjectName('title')
        layout.addWidget(title)

        # ── Body: drop zone + form side by side ───────────────────────────────
        body_row = QHBoxLayout()
        body_row.setSpacing(20)

        # Left: drop zone + auto-detect
        left_col = QVBoxLayout()
        left_col.setSpacing(10)

        # DropZone растягивается чтобы заполнить доступное место
        self._drop_zone = DropZone()
        self._drop_zone.path_dropped.connect(self._on_file_dropped)
        self._drop_zone.mousePressEvent = self._browse_file
        self._drop_zone.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        left_col.addWidget(self._drop_zone, 1)   # stretch=1 — тянется

        browse_row = QHBoxLayout()
        browse_row.setSpacing(6)
        browse_file_btn = QPushButton('Файл...')
        browse_file_btn.setObjectName('secondary')
        browse_file_btn.setIcon(make_icon('file', ICON_SECONDARY, 14))
        browse_file_btn.setIconSize(QSize(14, 14))
        browse_file_btn.clicked.connect(self._browse_file)
        browse_row.addWidget(browse_file_btn, 1)

        browse_dir_btn = QPushButton('Папка...')
        browse_dir_btn.setObjectName('secondary')
        browse_dir_btn.setIcon(make_icon('folder', ICON_SECONDARY, 14))
        browse_dir_btn.setIconSize(QSize(14, 14))
        browse_dir_btn.clicked.connect(self._browse_folder)
        browse_row.addWidget(browse_dir_btn, 1)
        left_col.addLayout(browse_row)

        self._detect_btn = QPushButton('Определить автоматически')
        self._detect_btn.setObjectName('secondary')
        self._detect_btn.setIcon(make_icon('detect', ICON_SECONDARY, 14))
        self._detect_btn.setIconSize(QSize(14, 14))
        self._detect_btn.clicked.connect(self._auto_detect)
        left_col.addWidget(self._detect_btn)

        # Version prefix reference
        prefix_box = QGroupBox('Префиксы версий')
        prefix_layout = QVBoxLayout(prefix_box)
        prefix_layout.setSpacing(4)
        self._prefix_lbl = QLabel()
        self._prefix_lbl.setObjectName('muted')
        self._prefix_lbl.setWordWrap(True)
        prefix_layout.addWidget(self._prefix_lbl)
        left_col.addWidget(prefix_box)

        # Rules selection
        rules_box = QGroupBox('Правила (для каких шкафов)')
        rules_layout = QVBoxLayout(rules_box)
        self._rules_list = QListWidget()
        self._rules_list.setSelectionMode(QAbstractItemView.NoSelection)
        self._rules_list.setMinimumHeight(120)
        self._rules_list.setMaximumHeight(220)
        rules_layout.addWidget(self._rules_list)
        left_col.addWidget(rules_box)

        # Create rule inline button
        create_rule_btn = QPushButton('Создать правило')
        create_rule_btn.setObjectName('secondary')
        create_rule_btn.setIcon(make_icon('plus', ICON_SECONDARY, 14))
        create_rule_btn.setIconSize(QSize(14, 14))
        create_rule_btn.clicked.connect(self._create_rule_inline)
        left_col.addWidget(create_rule_btn)

        body_row.addLayout(left_col, 1)

        # Right: form
        right_col = QVBoxLayout()
        right_col.setSpacing(12)

        # Форма метаданных прокручивается — кнопка «Загрузить» всегда видна
        form_box = QGroupBox('Метаданные')
        form_box_vlay = QVBoxLayout(form_box)
        form_box_vlay.setContentsMargins(4, 4, 4, 4)
        form_scroll = QScrollArea()
        form_scroll.setWidgetResizable(True)
        form_scroll.setFrameShape(QFrame.NoFrame)
        form_widget = QWidget()
        form = QFormLayout(form_widget)
        form.setSpacing(10)
        form.setLabelAlignment(Qt.AlignRight)
        form_scroll.setWidget(form_widget)
        form_box_vlay.addWidget(form_scroll)

        self._ver_input = QLineEdit()
        self._ver_input.setPlaceholderText('напр. 42 или 35.6 (префикс добавится автоматически)')
        self._ver_input.editingFinished.connect(self._auto_date_if_needed)
        form.addRow('Версия *', self._ver_input)

        self._ctrl_combo = QComboBox()
        self._ctrl_combo.setEditable(True)
        form.addRow('Контроллер', self._ctrl_combo)

        self._eq_combo = QComboBox()
        self._eq_combo.setEditable(True)
        self._eq_combo.currentTextChanged.connect(self._on_equip_changed)
        form.addRow('Тип оборудования', self._eq_combo)

        self._work_list = QListWidget()
        self._work_list.setSelectionMode(QAbstractItemView.MultiSelection)
        self._work_list.setFixedHeight(80)
        form.addRow('Тип работы', self._work_list)

        self._desc_edit = QTextEdit()
        self._desc_edit.setPlaceholderText('Краткое описание версии')
        self._desc_edit.setFixedHeight(72)
        form.addRow('Описание', self._desc_edit)

        self._changelog_edit = QTextEdit()
        self._changelog_edit.setPlaceholderText('Список изменений')
        self._changelog_edit.setFixedHeight(72)
        form.addRow('Изменения', self._changelog_edit)

        # IO map row (drag-and-drop supported)
        self._io_map_input = MiniDropZone()
        form.addRow('Карта in/out', self._make_path_row(
            self._io_map_input, self._browse_io_map_file, self._browse_io_map_dir))

        self._instructions_input = MiniDropZone()
        form.addRow('Инструкция', self._make_path_row(
            self._instructions_input,
            lambda: self._browse_path_into(self._instructions_input, file=True),
            lambda: self._browse_path_into(self._instructions_input, folder=True)))

        right_col.addWidget(form_box, 1)  # растягивается по высоте

        # Status / validation label
        self._status_lbl = QLabel('')
        self._status_lbl.setObjectName('subtitle')
        self._status_lbl.setWordWrap(True)
        right_col.addWidget(self._status_lbl)

        # Upload button
        self._upload_btn = QPushButton('Загрузить прошивку')
        self._upload_btn.setMinimumHeight(40)
        self._upload_btn.setIcon(make_icon('upload', ICON_ON_ACCENT, 16))
        self._upload_btn.setIconSize(QSize(16, 16))
        self._upload_btn.clicked.connect(self._do_upload)
        right_col.addWidget(self._upload_btn)

        right_col.addStretch()
        body_row.addLayout(right_col, 1)

        layout.addLayout(body_row)

        # Populate combos immediately (in case showEvent fires late)
        from PySide6.QtCore import QTimer
        QTimer.singleShot(0, self._reload_combos)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def showEvent(self, event):
        """Reload combos and rules when page becomes visible."""
        super().showEvent(event)
        self._reload_combos()
        self._reload_rules()
        self._reload_prefix_lbl()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _reload_combos(self):
        cfg = self._mw.cfg
        for combo, items in [
            (self._ctrl_combo, cfg.controller_types()),
            (self._eq_combo,   cfg.equipment_types()),
        ]:
            current = combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(items)
            idx = combo.findText(current)
            if idx >= 0:
                combo.setCurrentIndex(idx)
            combo.blockSignals(False)
        # Reload work_list (multi-select)
        selected = {
            self._work_list.item(i).text()
            for i in range(self._work_list.count())
            if self._work_list.item(i).isSelected()
        }
        self._work_list.clear()
        for wt in cfg.work_types():
            item = QListWidgetItem(wt)
            self._work_list.addItem(item)
            if wt in selected:
                item.setSelected(True)

    def _reload_rules(self):
        self._rules_list.clear()
        for rule in self._mw.db.get_all_rules():
            item = QListWidgetItem(rule.name)
            item.setData(Qt.UserRole, rule)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self._rules_list.addItem(item)

    def _reload_prefix_lbl(self):
        prefixes = self._mw.cfg.version_prefixes()
        if prefixes:
            parts = [f'{k} → {v}' for k, v in prefixes.items()]
            self._prefix_lbl.setText(' | '.join(parts))
        else:
            self._prefix_lbl.setText('(не заданы)')

    def _selected_rules(self) -> list[str]:
        return [
            self._rules_list.item(i).data(Qt.UserRole).name
            for i in range(self._rules_list.count())
            if self._rules_list.item(i).checkState() == Qt.Checked
        ]

    # ── Version prefix auto-substitution ──────────────────────────────────────

    def _on_equip_changed(self, text: str):
        prefixes = self._mw.cfg.version_prefixes()
        prefix = prefixes.get(text, '')
        if not prefix:
            return
        cur = self._ver_input.text().strip()
        known_prefix_values = set(prefixes.values())
        if not cur:
            self._ver_input.setText(prefix + '.')
            return
        parts = cur.split('.')
        # Already correct prefix in a multi-part version — nothing to do
        if parts[0] == prefix and len(parts) > 1:
            return
        # Multi-part version starting with a DIFFERENT known prefix → replace prefix
        if len(parts) > 1 and parts[0] in known_prefix_values:
            parts[0] = prefix
            self._ver_input.setText('.'.join(parts))
        else:
            # Single number OR first part is not a known prefix → always prepend.
            # A single digit is treated as version body, never as an old prefix.
            self._ver_input.setText(prefix + '.' + cur)

    # ── Auto-date insertion ────────────────────────────────────────────────────

    def _auto_date_if_needed(self):
        """Auto-append YYMMDD when user leaves version field without a date."""
        from datetime import date
        cur = self._ver_input.text().strip()
        if not cur:
            return
        parts = cur.split('.')
        # Date is already present if last segment is exactly 6 digits
        if len(parts) >= 3 and parts[-1].isdigit() and len(parts[-1]) == 6:
            return
        if len(parts) >= 2 and all(p.strip() for p in parts):
            today = date.today().strftime('%y%m%d')
            self._ver_input.setText(f'{cur}.{today}')

    def _insert_date(self):
        from datetime import date
        today = date.today().strftime('%y%m%d')
        cur = self._ver_input.text()
        parts = cur.split('.')
        if len(parts) >= 3 and parts[-1].isdigit() and len(parts[-1]) == 6:
            parts[-1] = today
            self._ver_input.setText('.'.join(parts))
        elif len(parts) >= 2:
            self._ver_input.setText(f'{cur}.{today}')
        else:
            self._ver_input.setText(cur + '.' + today if cur else today)

    # ── Path row helper ───────────────────────────────────────────────────────

    @staticmethod
    def _make_path_row(field: 'MiniDropZone', on_file, on_folder) -> 'QWidget':
        """MiniDropZone слева (растягивается) + кнопки «×», «Файл», «Папка» справа."""
        wrapper = QWidget()
        hlay = QHBoxLayout(wrapper)
        hlay.setContentsMargins(0, 0, 0, 0)
        hlay.setSpacing(6)
        hlay.addWidget(field, 1)

        clr = QPushButton('×')
        clr.setObjectName('secondary')
        clr.setFixedWidth(28)
        clr.setToolTip('Очистить')
        clr.clicked.connect(lambda *_, f=field: f.set_path(''))
        hlay.addWidget(clr)

        fb = QPushButton('Файл')
        fb.setObjectName('secondary')
        fb.setIcon(make_icon('file', ICON_SECONDARY, 14))
        fb.setIconSize(QSize(14, 14))
        fb.clicked.connect(on_file)
        hlay.addWidget(fb)

        db = QPushButton('Папка')
        db.setObjectName('secondary')
        db.setIcon(make_icon('folder', ICON_SECONDARY, 14))
        db.setIconSize(QSize(14, 14))
        db.clicked.connect(on_folder)
        hlay.addWidget(db)

        return wrapper

    # ── Path browsing ─────────────────────────────────────────────────────────

    def _browse_path_into(self, line_edit, file: bool = False, folder: bool = False):
        if file:
            path, _ = QFileDialog.getOpenFileName(self, 'Выберите файл', '', 'Все файлы (*.*)')
        else:
            path = QFileDialog.getExistingDirectory(self, 'Выберите папку', '')
        if path:
            line_edit.setText(path)

    def _browse_io_map_file(self):
        self._browse_path_into(self._io_map_input, file=True)

    def _browse_io_map_dir(self):
        self._browse_path_into(self._io_map_input, folder=True)

    # ── Create rule inline ────────────────────────────────────────────────────

    def _create_rule_inline(self):
        from app.ui.pages.settings_page import _RuleDialog
        dlg = _RuleDialog(self, self._mw.cfg, db=self._mw.db)
        if dlg.exec() == QDialog.Accepted:
            rule = dlg.get_rule()
            self._mw.db.upsert_rule(rule)
            dlg.save_template_links(rule.name, self._mw.db)
            self._reload_rules()
            self._mw.show_status(f'Правило создано: {rule.name}')

    def _create_rule_for_upload(self) -> list[str]:
        """Auto-find existing rule or silently create one. No dialogs. Returns [rule.name]."""
        import re as _re
        from app.domain.models import Rule
        from datetime import datetime as _dt

        eq   = self._eq_combo.currentText().strip()
        ctrl = self._ctrl_combo.currentText().strip()

        # Auto-generate software name from controller + equipment type
        sw_name = ' '.join(p for p in [ctrl, eq] if p)

        # 1. Look for an existing rule that matches eq/controller
        #    Require BOTH to match when both values are provided — avoids false
        #    positives where different equipment shares the same controller.
        for rule in self._mw.db.get_all_rules():
            eq_match = eq and rule.equipment_type and (
                eq.lower() in rule.equipment_type.lower() or
                rule.equipment_type.lower() in eq.lower()
            )
            ctrl_match = ctrl and rule.controller and (
                ctrl.lower() in rule.controller.lower() or
                rule.controller.lower() in ctrl.lower()
            )
            if eq and ctrl:
                match = bool(eq_match and ctrl_match)
            elif eq:
                match = bool(eq_match)
            else:
                # Same controller can be used across different equipment types —
                # never match by controller alone to avoid overwriting wrong rule.
                match = False
            if match:
                # Fill software_name if missing
                if sw_name and not rule.software_name:
                    from dataclasses import replace as _dc
                    self._mw.db.upsert_rule(_dc(rule, software_name=sw_name))
                if ctrl.upper() == 'KINCO' and rule.firmware_type != 'plc_hmi':
                    from dataclasses import replace as _dc2
                    self._mw.db.upsert_rule(_dc2(rule, firmware_type='plc_hmi'))
                for i in range(self._rules_list.count()):
                    item = self._rules_list.item(i)
                    if item.data(Qt.UserRole).name == rule.name:
                        item.setCheckState(Qt.Checked)
                self._mw.show_status(f'Автовыбрано правило: {rule.name}')
                return [rule.name]

        # 2. No match — silently create a minimal rule
        parts = [p for p in [eq, ctrl] if p]
        raw_name = ' '.join(parts) if parts else 'Прошивка'
        existing_names = {r.name for r in self._mw.db.get_all_rules()}
        name, n = raw_name, 2
        while name in existing_names:
            name = f'{raw_name} {n}'
            n += 1

        fw_dir = _re.sub(r'[^\w\-]', '_', '/'.join(parts)) if parts else 'firmware'

        rule = Rule(
            id=None,
            name=name,
            equipment_type=eq,
            work_type=', '.join(
                self._work_list.item(i).text()
                for i in range(self._work_list.count())
                if self._work_list.item(i).isSelected()
            ),
            controller=ctrl,
            firmware_dir=fw_dir,
            firmware_type='plc_hmi' if ctrl.upper() == 'KINCO' else 'plc',
            software_name=sw_name,
            keywords=[],
            exclude_keywords=[],
            kw_mode='any',
            local_dir='',
            local_synced=False,
            disk_snapshot={},
            created_at=_dt.now(),
            updated_at=_dt.now(),
        )
        self._mw.db.upsert_rule(rule)
        self._reload_rules()
        for i in range(self._rules_list.count()):
            item = self._rules_list.item(i)
            if item.data(Qt.UserRole).name == rule.name:
                item.setCheckState(Qt.Checked)
        self._mw.show_status(f'Правило создано автоматически: {rule.name}')
        return [rule.name]

    # ── File selection ────────────────────────────────────────────────────────

    def _browse_file(self, event=None):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Выберите файл прошивки', '',
            'Все файлы (*.*)'
        )
        if path:
            self._on_file_dropped(path)

    def _browse_folder(self):
        path = QFileDialog.getExistingDirectory(self, 'Выберите папку прошивки', '')
        if path:
            self._on_file_dropped(path)

    def _on_file_dropped(self, path: str):
        self._src_path = path
        self._status_lbl.setText(f'Файл: {os.path.basename(path)}')
        # Auto-detect on drop
        self._auto_detect()

    # ── Auto-detect ───────────────────────────────────────────────────────────

    def _auto_detect(self):
        if not self._src_path:
            self._status_lbl.setText('Сначала выберите файл.')
            return
        try:
            info = self._mw.upload_svc.auto_detect(self._src_path)
        except Exception as e:
            self._status_lbl.setText(f'Ошибка определения: {e}')
            return

        # Fill fields with detected values
        if info.get('suggested_version'):
            self._ver_input.setText(info['suggested_version'])
        elif info.get('version'):
            self._ver_input.setText(info['version'])

        if info.get('controller'):
            idx = self._ctrl_combo.findText(info['controller'])
            if idx >= 0:
                self._ctrl_combo.setCurrentIndex(idx)
            else:
                self._ctrl_combo.setCurrentText(info['controller'])

        if info.get('device_type'):
            idx = self._eq_combo.findText(info['device_type'])
            if idx >= 0:
                self._eq_combo.setCurrentIndex(idx)
            else:
                self._eq_combo.setCurrentText(info['device_type'])

        # Auto-select matching rules (AND logic: both eq+ctrl must match when both present)
        detected_eq   = info.get('device_type', '')
        detected_ctrl = info.get('controller', '')
        if detected_eq or detected_ctrl:
            for i in range(self._rules_list.count()):
                item = self._rules_list.item(i)
                rule = item.data(Qt.UserRole)
                eq_match = bool(detected_eq and rule.equipment_type and (
                    detected_eq.lower() in rule.equipment_type.lower() or
                    rule.equipment_type.lower() in detected_eq.lower()
                ))
                ctrl_match = bool(detected_ctrl and rule.controller and (
                    detected_ctrl.lower() in rule.controller.lower() or
                    rule.controller.lower() in detected_ctrl.lower()
                ))
                if detected_eq and detected_ctrl:
                    match = eq_match and ctrl_match
                elif detected_eq:
                    match = eq_match
                else:
                    # Don't auto-check based on controller alone: one controller
                    # is used by many equipment types, so matching by ctrl only
                    # would check wrong rules (e.g. ПЖ when loading НГР).
                    match = False
                item.setCheckState(Qt.Checked if match else Qt.Unchecked)

        # Always sync instructions field from first matched rule (clears if rule has none).
        # Without this, dropping a new file would preserve instructions from the previous file.
        new_instr = ''
        for i in range(self._rules_list.count()):
            item = self._rules_list.item(i)
            if item.checkState() == Qt.Checked:
                new_instr = item.data(Qt.UserRole).instructions_path or ''
                break
        self._instructions_input.set_path(new_instr)

        self._status_lbl.setText('Данные определены автоматически')

    # ── Version normalization ─────────────────────────────────────────────────

    def _normalize_version(self, ver_str: str) -> str:
        """Expand shorthand input to full prefix.body.YYMMDD.

        Accepted shorthands (prefix from current equipment type, date = today):
          "42"          → "3.42.260418"     (prefix prepended, date appended)
          "35.6"        → "4.35.6.260418"   (prefix prepended, date appended)
          "4.35"        → "4.35.260418"     (date appended)
          "4.35.6"      → "4.35.6.260418"   (date appended)
          "4.35.260418" → unchanged
        """
        from datetime import date
        today = date.today().strftime('%y%m%d')
        if not ver_str:
            return ver_str

        parts = ver_str.split('.')
        prefixes = self._mw.cfg.version_prefixes()
        known_prefix_values = set(prefixes.values())
        eq = self._eq_combo.currentText().strip()
        eq_prefix = prefixes.get(eq, '')

        # Prepend prefix unless user already typed the correct prefix as first segment
        # (i.e. parts[0] == eq_prefix AND there are more parts beyond it).
        # A single number is always treated as the version body, never as a prefix.
        should_prepend = eq_prefix and not (parts[0] == eq_prefix and len(parts) > 1)
        if should_prepend:
            parts = [eq_prefix] + parts

        # Append date if last segment is not already a 6-digit date
        if not (parts[-1].isdigit() and len(parts[-1]) == 6) and len(parts) >= 2:
            parts.append(today)

        return '.'.join(parts)

    # ── Upload ────────────────────────────────────────────────────────────────

    def _do_upload(self):
        if not self._src_path:
            QMessageBox.warning(self, 'Загрузка', 'Выберите файл прошивки.')
            return

        ver_str    = self._normalize_version(self._ver_input.text().strip())
        self._ver_input.setText(ver_str)   # show the expanded version to user
        rule_names = self._selected_rules()

        if not ver_str:
            QMessageBox.warning(self, 'Загрузка', 'Укажите версию прошивки.')
            return
        if not rule_names:
            rule_names = self._create_rule_for_upload()
            if not rule_names:
                return

        # Pre-validate version conflicts
        try:
            conflicts = self._mw.upload_svc.validate_version(ver_str, rule_names)
        except InvalidVersionError:
            QMessageBox.critical(self, 'Ошибка',
                f'Неверный формат версии: {ver_str}\n'
                'Ожидается: prefix.тело[.YYMMDD]\n'
                'Примеры: 3.42.260414 или 4.35.6.260421')
            return

        if conflicts:
            msg = 'Конфликт версий:\n\n' + '\n'.join(conflicts)
            msg += '\n\nВсё равно загрузить?'
            reply = QMessageBox.question(self, 'Конфликт версий', msg,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply != QMessageBox.Yes:
                return

        try:
            fv = self._mw.upload_svc.upload(
                src_path    = self._src_path,
                version_str = ver_str,
                rule_names  = rule_names,
                controller  = self._ctrl_combo.currentText().strip(),
                device_type = self._eq_combo.currentText().strip(),
                work_type   = ', '.join(
                    self._work_list.item(i).text()
                    for i in range(self._work_list.count())
                    if self._work_list.item(i).isSelected()
                ),
                description = self._desc_edit.toPlainText().strip(),
                changelog   = self._changelog_edit.toPlainText().strip(),
                allow_equal = conflicts != [],
                io_map_path = self._io_map_input.text().strip(),
            )
        except VersionConflictError as e:
            QMessageBox.critical(self, 'Конфликт версий', str(e))
            return
        except FileOperationError as e:
            QMessageBox.critical(self, 'Ошибка файла', str(e))
            return
        except Exception as e:
            QMessageBox.critical(self, 'Ошибка', str(e))
            return

        # Always save instructions/io_map to rule when provided in the form
        # (allows updating the path on subsequent uploads; clears via Settings→Rules)
        instr_path = self._instructions_input.text().strip()
        io_map     = self._io_map_input.text().strip()
        from dataclasses import replace as _dc
        for rn in rule_names:
            rule = self._mw.db.get_rule(rn)
            if not rule:
                continue
            updates: dict = {}
            updates['instructions_path'] = instr_path  # always sync: clears if user hit ×
            if io_map:
                updates['io_map_path'] = io_map
            self._mw.db.upsert_rule(_dc(rule, **updates))

        self._mw.show_status(f'Загружено: {fv.version} — {", ".join(rule_names)}')
        QMessageBox.information(self, 'Готово',
            f'Прошивка {fv.version} успешно загружена.\n'
            f'Правила: {", ".join(rule_names)}\n'
            f'Путь: {fv.local_path}')
        self._reset_form()

    def _reset_form(self):
        self._src_path = ''
        self._drop_zone.reset()
        self._ver_input.clear()
        self._desc_edit.clear()
        self._changelog_edit.clear()
        self._io_map_input.clear()
        self._instructions_input.clear()
        for i in range(self._rules_list.count()):
            self._rules_list.item(i).setCheckState(Qt.Unchecked)
        self._work_list.clearSelection()
        self._status_lbl.setText('')
