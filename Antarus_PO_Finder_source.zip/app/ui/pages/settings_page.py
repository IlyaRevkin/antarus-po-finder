"""
FirmwareFinder — Settings Page
==================================
Administrator-only settings: root path, roles, rules CRUD, prefixes, quick apps.
"""

import os
import json
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QStackedWidget,
    QLabel, QLineEdit, QPushButton, QComboBox, QListWidget,
    QListWidgetItem, QMessageBox, QGroupBox, QFileDialog,
    QDialog, QTextEdit, QDialogButtonBox, QAbstractItemView,
    QTableWidget, QTableWidgetItem, QHeaderView, QCheckBox,
    QScrollArea, QFrame, QInputDialog,
)
from PySide6.QtCore import Qt, QSize
from app.ui.icons import make_icon, ICON_SECONDARY, ICON_ON_ACCENT

from app.domain.models import Rule
from app.ui.widgets.drop_zone import PathDropEdit, MiniDropZone
from datetime import datetime


class SettingsPage(QWidget):
    def __init__(self, main_win):
        super().__init__()
        self._mw = main_win
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 16)
        layout.setSpacing(16)

        title = QLabel('Настройки')
        title.setObjectName('title')
        layout.addWidget(title)

        # ── Custom tab bar (QPushButton row + QStackedWidget) ──────────────────
        # QTabWidget::tab QSS is ignored by the Windows native style, so we
        # build our own tab bar to get full CSS control.
        tab_defs = [
            ('Общие',       self._build_general_tab),
            ('Правила',     self._build_rules_tab),
            ('Префиксы',    self._build_prefixes_tab),
            ('Приложения',  self._build_quickapps_tab),
            ('Типы',        self._build_types_tab),
        ]

        tab_bar = QHBoxLayout()
        tab_bar.setSpacing(4)
        tab_bar.setContentsMargins(0, 0, 0, 0)
        self._tab_btns: list[QPushButton] = []
        self._tab_stack = QStackedWidget()

        for i, (label, builder) in enumerate(tab_defs):
            btn = QPushButton(label)
            btn.setObjectName('tab-btn')
            btn.setCheckable(True)
            btn.setFixedHeight(34)
            btn.clicked.connect(lambda checked, idx=i: self._switch_tab(idx))
            tab_bar.addWidget(btn)
            self._tab_btns.append(btn)
            self._tab_stack.addWidget(builder())

        tab_bar.addStretch()
        layout.addLayout(tab_bar)
        layout.addWidget(self._tab_stack, 1)

        self._switch_tab(0)

    def _switch_tab(self, idx: int):
        self._tab_stack.setCurrentIndex(idx)
        for i, btn in enumerate(self._tab_btns):
            btn.setChecked(i == idx)

    # ═══════════════════════════ GENERAL TAB ══════════════════════════════════

    def _build_general_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(20)

        # ── Disk path ─────────────────────────────────────────────────────────
        disk_box = QGroupBox('Путь к диску (WebDAV / сетевая папка)')
        disk_layout = QHBoxLayout(disk_box)
        self._root_path_input = QLineEdit()
        self._root_path_input.setFixedHeight(34)
        disk_layout.addWidget(self._root_path_input, 1)
        browse_btn = QPushButton('…')
        browse_btn.setFixedWidth(36)
        browse_btn.setObjectName('secondary')
        browse_btn.clicked.connect(self._browse_root)
        disk_layout.addWidget(browse_btn)
        save_disk_btn = QPushButton('Сохранить')
        save_disk_btn.setObjectName('secondary')
        save_disk_btn.clicked.connect(self._save_root_path)
        disk_layout.addWidget(save_disk_btn)
        layout.addWidget(disk_box)

        # ── Role switch ───────────────────────────────────────────────────────
        role_box = QGroupBox('Сменить роль')
        role_layout = QHBoxLayout(role_box)
        self._role_combo = QComboBox()
        self._role_combo.addItem('Наладчик',      'naladchik')
        self._role_combo.addItem('Программист',   'programmer')
        self._role_combo.addItem('Администратор', 'administrator')
        role_layout.addWidget(self._role_combo)

        self._pwd_input = QLineEdit()
        self._pwd_input.setPlaceholderText('Пароль (если требуется)')
        self._pwd_input.setEchoMode(QLineEdit.Password)
        self._pwd_input.setFixedHeight(34)
        role_layout.addWidget(self._pwd_input, 1)

        switch_btn = QPushButton('Сменить')
        switch_btn.clicked.connect(self._switch_role)
        role_layout.addWidget(switch_btn)
        layout.addWidget(role_box)

        # ── Passwords ─────────────────────────────────────────────────────────
        pwd_box = QGroupBox('Пароли доступа')
        pwd_form = QFormLayout(pwd_box)
        self._admin_pwd = QLineEdit(self._mw.cfg.admin_password())
        self._admin_pwd.setEchoMode(QLineEdit.Password)
        self._admin_pwd.setFixedHeight(34)
        pwd_form.addRow('Пароль администратора', self._admin_pwd)

        self._prog_pwd = QLineEdit(self._mw.cfg.programmer_password())
        self._prog_pwd.setEchoMode(QLineEdit.Password)
        self._prog_pwd.setFixedHeight(34)
        pwd_form.addRow('Пароль программиста', self._prog_pwd)

        save_pwd_btn = QPushButton('Сохранить пароли')
        save_pwd_btn.setObjectName('secondary')
        save_pwd_btn.clicked.connect(self._save_passwords)
        pwd_form.addRow('', save_pwd_btn)
        layout.addWidget(pwd_box)

        # ── Misc ──────────────────────────────────────────────────────────────
        misc_box = QGroupBox('Прочее')
        misc_layout = QHBoxLayout(misc_box)
        self._keep_arch_cb = QCheckBox('Хранить архивы после извлечения')
        misc_layout.addWidget(self._keep_arch_cb)
        save_misc_btn = QPushButton('Сохранить')
        save_misc_btn.setObjectName('secondary')
        save_misc_btn.clicked.connect(self._save_misc)
        misc_layout.addWidget(save_misc_btn)
        layout.addWidget(misc_box)

        layout.addStretch()
        return w

    # ═══════════════════════════ RULES TAB ════════════════════════════════════

    def _build_rules_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        # Row 1: filter
        filter_row = QHBoxLayout()
        filter_row.setSpacing(8)
        self._rule_search = QLineEdit()
        self._rule_search.setPlaceholderText('Фильтр по имени…')
        self._rule_search.textChanged.connect(self._filter_rules)
        filter_row.addWidget(self._rule_search)
        layout.addLayout(filter_row)

        # Row 2: action buttons (right-aligned)
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        add_btn = QPushButton('Добавить')
        add_btn.setIcon(make_icon('plus', ICON_ON_ACCENT, 14))
        add_btn.setIconSize(QSize(14, 14))
        add_btn.clicked.connect(self._add_rule)
        btn_row.addWidget(add_btn)

        edit_btn = QPushButton('Изменить')
        edit_btn.setObjectName('secondary')
        edit_btn.setIcon(make_icon('edit', ICON_SECONDARY, 14))
        edit_btn.setIconSize(QSize(14, 14))
        edit_btn.clicked.connect(self._edit_rule)
        btn_row.addWidget(edit_btn)

        copy_btn = QPushButton('Копировать')
        copy_btn.setObjectName('secondary')
        copy_btn.setIcon(make_icon('copy', ICON_SECONDARY, 14))
        copy_btn.setIconSize(QSize(14, 14))
        copy_btn.clicked.connect(self._copy_rule)
        btn_row.addWidget(copy_btn)

        del_btn = QPushButton('Удалить')
        del_btn.setObjectName('danger')
        del_btn.setIcon(make_icon('trash', ICON_ON_ACCENT, 14))
        del_btn.setIconSize(QSize(14, 14))
        del_btn.clicked.connect(self._delete_rule)
        btn_row.addWidget(del_btn)

        btn_row.addStretch()
        layout.addLayout(btn_row)

        # Table
        self._rules_table = QTableWidget()
        self._rules_table.setColumnCount(4)
        self._rules_table.setHorizontalHeaderLabels(
            ['Название', 'Тип', 'Контроллер', 'Папка на диске']
        )
        hh = self._rules_table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.Stretch)
        self._rules_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._rules_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._rules_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._rules_table.verticalHeader().hide()
        self._rules_table.doubleClicked.connect(self._edit_rule)
        layout.addWidget(self._rules_table)

        self._rules_status = QLabel('')
        self._rules_status.setObjectName('muted')
        layout.addWidget(self._rules_status)

        return w

    # ═══════════════════════════ PREFIXES TAB ═════════════════════════════════

    def _build_prefixes_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        lbl = QLabel('Соответствие типа оборудования → номер версии (префикс)')
        lbl.setObjectName('subtitle')
        layout.addWidget(lbl)

        # Table for prefix editing
        self._prefix_table = QTableWidget()
        self._prefix_table.setColumnCount(2)
        self._prefix_table.setHorizontalHeaderLabels(['Тип оборудования', 'Префикс'])
        self._prefix_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self._prefix_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self._prefix_table.setFixedHeight(220)
        layout.addWidget(self._prefix_table)

        btn_row = QHBoxLayout()
        add_row_btn = QPushButton('Добавить строку')
        add_row_btn.setObjectName('secondary')
        add_row_btn.setIcon(make_icon('plus', ICON_SECONDARY, 14))
        add_row_btn.setIconSize(QSize(14, 14))
        add_row_btn.clicked.connect(self._add_prefix_row)
        btn_row.addWidget(add_row_btn)

        del_row_btn = QPushButton('Удалить строку')
        del_row_btn.setObjectName('secondary')
        del_row_btn.setIcon(make_icon('trash', ICON_SECONDARY, 14))
        del_row_btn.setIconSize(QSize(14, 14))
        del_row_btn.clicked.connect(self._del_prefix_row)
        btn_row.addWidget(del_row_btn)

        btn_row.addStretch()

        save_btn = QPushButton('Сохранить префиксы')
        save_btn.setIcon(make_icon('save', ICON_ON_ACCENT, 14))
        save_btn.setIconSize(QSize(14, 14))
        save_btn.clicked.connect(self._save_prefixes)
        btn_row.addWidget(save_btn)
        layout.addWidget(QLabel(''))
        layout.addLayout(btn_row)

        hint = QLabel(
            'Пример: КПЧ → 3 даст версию 3.42.260414\n'
            'Формат версии: prefix.тело.YYMMDD (тело может быть 42 или 35.6)'
        )
        hint.setObjectName('muted')
        layout.addWidget(hint)

        layout.addStretch()
        return w

    # ═══════════════════════════ QUICK APPS TAB ═══════════════════════════════

    def _build_quickapps_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        lbl = QLabel('Ярлыки для быстрого запуска (доступны наладчику в поиске)')
        lbl.setObjectName('subtitle')
        layout.addWidget(lbl)

        self._apps_table = QTableWidget()
        self._apps_table.setColumnCount(3)
        self._apps_table.setHorizontalHeaderLabels(['Название', 'Путь', 'Иконка'])
        self._apps_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self._apps_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self._apps_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self._apps_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._apps_table.verticalHeader().hide()
        layout.addWidget(self._apps_table)

        btn_row = QHBoxLayout()
        add_app_btn = QPushButton('Добавить')
        add_app_btn.setObjectName('secondary')
        add_app_btn.setIcon(make_icon('plus', ICON_SECONDARY, 14))
        add_app_btn.setIconSize(QSize(14, 14))
        add_app_btn.clicked.connect(self._add_app_row)
        btn_row.addWidget(add_app_btn)

        del_app_btn = QPushButton('Удалить')
        del_app_btn.setObjectName('secondary')
        del_app_btn.setIcon(make_icon('trash', ICON_SECONDARY, 14))
        del_app_btn.setIconSize(QSize(14, 14))
        del_app_btn.clicked.connect(self._del_app_row)
        btn_row.addWidget(del_app_btn)

        btn_row.addStretch()

        save_apps_btn = QPushButton('Сохранить')
        save_apps_btn.setIcon(make_icon('save', ICON_ON_ACCENT, 14))
        save_apps_btn.setIconSize(QSize(14, 14))
        save_apps_btn.clicked.connect(self._save_apps)
        btn_row.addWidget(save_apps_btn)
        layout.addLayout(btn_row)

        layout.addStretch()
        return w

    # ═══════════════════════════ TYPES TAB ════════════════════════════════════

    def _build_types_tab(self) -> QWidget:
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Scrollable area so content is accessible on any window height
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(16)

        for title, attr, cfg_key in [
            ('Типы оборудования', '_equip_list', 'equipment_types'),
            ('Типы работ',        '_work_list',  'work_types'),
            ('Типы контроллеров', '_ctrl_list',  'controller_types'),
        ]:
            box = QGroupBox(title)
            bl = QVBoxLayout(box)
            bl.setSpacing(6)
            lst = QListWidget()
            lst.setMinimumHeight(130)
            setattr(self, attr, lst)
            bl.addWidget(lst)
            btn_row = QHBoxLayout()
            btn_row.setSpacing(6)
            add_btn = QPushButton('Добавить')
            add_btn.setObjectName('secondary')
            add_btn.setIcon(make_icon('plus', ICON_SECONDARY, 14))
            add_btn.setIconSize(QSize(14, 14))
            del_btn = QPushButton('Удалить')
            del_btn.setObjectName('secondary')
            del_btn.setIcon(make_icon('trash', ICON_SECONDARY, 14))
            del_btn.setIconSize(QSize(14, 14))
            # Use lambda to swallow the clicked(bool) signal arg so l stays bound
            add_btn.clicked.connect(lambda *_, l=lst: (
                lambda text, ok: l.addItem(text.strip()) if ok and text.strip() else None
            )(*QInputDialog.getText(self, 'Добавить', 'Новое значение:')))
            del_btn.clicked.connect(lambda *_, l=lst: (
                l.takeItem(l.currentRow()) if l.currentRow() >= 0 else None
            ))
            btn_row.addWidget(add_btn)
            btn_row.addWidget(del_btn)
            btn_row.addStretch()
            bl.addLayout(btn_row)
            layout.addWidget(box)

        save_btn = QPushButton('Сохранить все типы')
        save_btn.setIcon(make_icon('save', ICON_ON_ACCENT, 14))
        save_btn.setIconSize(QSize(14, 14))
        save_btn.clicked.connect(self._save_types)
        layout.addWidget(save_btn)
        layout.addStretch()

        scroll.setWidget(inner)
        outer.addWidget(scroll)
        return w

    def _load_types(self):
        for lst, cfg_key in [
            (self._equip_list, 'equipment_types'),
            (self._work_list,  'work_types'),
            (self._ctrl_list,  'controller_types'),
        ]:
            lst.clear()
            try:
                items = json.loads(self._mw.cfg.get(cfg_key))
            except Exception:
                items = []
            for item in items:
                lst.addItem(item)

    def _save_types(self):
        for lst, cfg_key in [
            (self._equip_list, 'equipment_types'),
            (self._work_list,  'work_types'),
            (self._ctrl_list,  'controller_types'),
        ]:
            items = [lst.item(i).text() for i in range(lst.count())]
            self._mw.cfg.set(cfg_key, json.dumps(items, ensure_ascii=False))
        self._mw.show_status('Типы сохранены')

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def showEvent(self, event):
        super().showEvent(event)
        self._load_general()
        self._load_rules()
        self._load_prefixes()
        self._load_apps()
        self._load_types()

    # ── General load/save ─────────────────────────────────────────────────────

    def _load_general(self):
        self._root_path_input.setText(self._mw.cfg.root_path())
        keep = self._mw.cfg.keep_archives()
        self._keep_arch_cb.setChecked(keep)

        role = self._mw.current_role()
        for i in range(self._role_combo.count()):
            if self._role_combo.itemData(i) == role:
                self._role_combo.setCurrentIndex(i)
                break

    def _browse_root(self):
        path = QFileDialog.getExistingDirectory(self, 'Папка прошивок', '')
        if path:
            self._root_path_input.setText(path)

    def _save_root_path(self):
        self._mw.cfg.set_root_path(self._root_path_input.text().strip())
        self._mw.show_status('Путь сохранён')

    def _save_passwords(self):
        self._mw.cfg.set('admin_password',      self._admin_pwd.text())
        self._mw.cfg.set('programmer_password',  self._prog_pwd.text())
        self._mw.show_status('Пароли сохранены')

    def _save_misc(self):
        self._mw.cfg.set('keep_archives', 'true' if self._keep_arch_cb.isChecked() else 'false')
        self._mw.show_status('Настройки сохранены')

    def _switch_role(self):
        role = self._role_combo.currentData()
        pwd  = self._pwd_input.text()

        if role == 'administrator':
            expected = self._mw.cfg.admin_password()
            if pwd != expected:
                QMessageBox.warning(self, 'Доступ', 'Неверный пароль администратора.')
                return
        elif role == 'programmer':
            expected = self._mw.cfg.programmer_password()
            if expected and pwd != expected:
                QMessageBox.warning(self, 'Доступ', 'Неверный пароль программиста.')
                return

        self._mw.switch_role(role)
        self._pwd_input.clear()
        self._mw.show_status(f'Роль изменена: {self._role_combo.currentText()}')

    # ── Rules load/save ───────────────────────────────────────────────────────

    def _load_rules(self):
        rules = self._mw.db.get_all_rules()
        self._all_rules = rules
        self._populate_rules(rules)

    def _populate_rules(self, rules: list[Rule]):
        self._rules_table.setRowCount(len(rules))
        for row, r in enumerate(rules):
            self._rules_table.setItem(row, 0, QTableWidgetItem(r.name))
            self._rules_table.setItem(row, 1, QTableWidgetItem(r.equipment_type))
            self._rules_table.setItem(row, 2, QTableWidgetItem(r.controller))
            self._rules_table.setItem(row, 3, QTableWidgetItem(r.firmware_dir))
            self._rules_table.item(row, 0).setData(Qt.UserRole, r)
        self._rules_status.setText(f'Правил: {len(rules)}')

    def _filter_rules(self, text: str):
        text = text.lower()
        filtered = [r for r in self._all_rules if text in r.name.lower()] if text else self._all_rules
        self._populate_rules(filtered)

    def _selected_rule(self) -> Rule | None:
        row = self._rules_table.currentRow()
        if row < 0:
            return None
        item = self._rules_table.item(row, 0)
        return item.data(Qt.UserRole) if item else None

    def _add_rule(self):
        dlg = _RuleDialog(self, self._mw.cfg, db=self._mw.db)
        if dlg.exec() == QDialog.Accepted:
            rule = dlg.get_rule()
            self._mw.db.upsert_rule(rule)
            dlg.save_template_links(rule.name, self._mw.db)
            self._load_rules()

    def _edit_rule(self):
        rule = self._selected_rule()
        if not rule:
            QMessageBox.information(self, 'Изменить', 'Выберите правило.')
            return
        dlg = _RuleDialog(self, self._mw.cfg, rule=rule, db=self._mw.db)
        if dlg.exec() == QDialog.Accepted:
            updated = dlg.get_rule()
            self._mw.db.upsert_rule(updated)
            dlg.save_template_links(updated.name, self._mw.db)
            self._load_rules()

    def _copy_rule(self):
        rule = self._selected_rule()
        if not rule:
            QMessageBox.information(self, 'Копировать', 'Выберите правило.')
            return
        from dataclasses import replace as _dc
        # Generate unique name
        existing = {r.name for r in self._mw.db.get_all_rules()}
        base = f'{rule.name} (копия)'
        name, n = base, 2
        while name in existing:
            name = f'{base} {n}'
            n += 1
        new_rule = _dc(rule, id=None, name=name,
                       local_synced=False, disk_snapshot={})
        self._mw.db.upsert_rule(new_rule)
        self._load_rules()
        self._mw.show_status(f'Правило скопировано: {name}')

    def _delete_rule(self):
        rule = self._selected_rule()
        if not rule:
            QMessageBox.information(self, 'Удалить', 'Выберите правило.')
            return
        reply = QMessageBox.question(self, 'Удалить правило',
            f'Удалить правило «{rule.name}»?\n'
            'Загруженные версии останутся в базе.',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self._mw.db.delete_rule(rule.id)
            self._load_rules()

    # ── Prefix load/save ──────────────────────────────────────────────────────

    def _load_prefixes(self):
        prefixes = self._mw.cfg.version_prefixes()
        self._prefix_table.setRowCount(len(prefixes))
        for row, (k, v) in enumerate(prefixes.items()):
            self._prefix_table.setItem(row, 0, QTableWidgetItem(k))
            self._prefix_table.setItem(row, 1, QTableWidgetItem(str(v)))

    def _add_prefix_row(self):
        row = self._prefix_table.rowCount()
        self._prefix_table.insertRow(row)

    def _del_prefix_row(self):
        row = self._prefix_table.currentRow()
        if row >= 0:
            self._prefix_table.removeRow(row)

    def _save_prefixes(self):
        data = {}
        for row in range(self._prefix_table.rowCount()):
            k_item = self._prefix_table.item(row, 0)
            v_item = self._prefix_table.item(row, 1)
            if k_item and v_item and k_item.text().strip():
                data[k_item.text().strip()] = v_item.text().strip()
        self._mw.cfg.set('version_prefixes', json.dumps(data, ensure_ascii=False))
        self._mw.show_status('Префиксы сохранены')

    # ── Quick apps load/save ──────────────────────────────────────────────────

    def _load_apps(self):
        apps = self._mw.cfg.quick_apps()
        self._apps_table.setRowCount(len(apps))
        for row, app in enumerate(apps):
            self._apps_table.setItem(row, 0, QTableWidgetItem(app.get('name', '')))
            self._apps_table.setItem(row, 1, QTableWidgetItem(app.get('path', '')))
            self._apps_table.setItem(row, 2, QTableWidgetItem(app.get('icon', '')))

    def _add_app_row(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Выбрать приложение', '',
            'Исполняемые файлы (*.exe *.bat *.lnk);;Все файлы (*.*)'
        )
        if not path:
            return
        row = self._apps_table.rowCount()
        self._apps_table.insertRow(row)
        name = os.path.splitext(os.path.basename(path))[0]
        self._apps_table.setItem(row, 0, QTableWidgetItem(name))
        self._apps_table.setItem(row, 1, QTableWidgetItem(path))
        self._apps_table.setItem(row, 2, QTableWidgetItem(''))

    def _del_app_row(self):
        row = self._apps_table.currentRow()
        if row >= 0:
            self._apps_table.removeRow(row)

    def _save_apps(self):
        apps = []
        for row in range(self._apps_table.rowCount()):
            name = (self._apps_table.item(row, 0) or QTableWidgetItem('')).text()
            path = (self._apps_table.item(row, 1) or QTableWidgetItem('')).text()
            icon = (self._apps_table.item(row, 2) or QTableWidgetItem('')).text()
            if name or path:
                apps.append({'name': name, 'path': path, 'icon': icon})
        self._mw.cfg.set_quick_apps(apps)
        self._mw.show_status('Быстрые приложения сохранены')


# ──────────────────────────────────────────────────────────────────────────────
# Rule dialog
# ──────────────────────────────────────────────────────────────────────────────

class _RuleDialog(QDialog):
    """Create / edit a Rule."""

    def __init__(self, parent, cfg, rule: Rule | None = None, db=None):
        super().__init__(parent)
        self._cfg  = cfg
        self._rule = rule
        self._db   = db
        self.setWindowTitle('Правило' if rule is None else f'Правило: {rule.name}')
        self.setMinimumWidth(560)
        self.setMinimumHeight(620)
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)

        # Scrollable form — viewport must also accept drops for PathDropEdit children
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setAcceptDrops(True)
        scroll.viewport().setAcceptDrops(True)
        form_widget = QWidget()
        form = QFormLayout(form_widget)
        form.setSpacing(10)
        form.setLabelAlignment(Qt.AlignRight)

        r = self._rule  # shortcut

        self._name = QLineEdit(r.name if r else '')
        self._name.setPlaceholderText('Уникальное имя правила')
        form.addRow('Название *', self._name)

        self._eq_combo = QComboBox()
        self._eq_combo.setEditable(True)
        self._eq_combo.addItems(self._cfg.equipment_types())
        if r and r.equipment_type:
            self._eq_combo.setCurrentText(r.equipment_type)
        form.addRow('Тип оборудования', self._eq_combo)

        self._work_list = QListWidget()
        self._work_list.setSelectionMode(QAbstractItemView.MultiSelection)
        self._work_list.setFixedHeight(90)
        for wt in self._cfg.work_types():
            item = QListWidgetItem(wt)
            self._work_list.addItem(item)
            if r and wt in [w.strip() for w in r.work_type.split(',')]:
                item.setSelected(True)
        form.addRow('Тип работы', self._work_list)

        self._ctrl_combo = QComboBox()
        self._ctrl_combo.setEditable(True)
        self._ctrl_combo.addItems(self._cfg.controller_types())
        if r and r.controller:
            self._ctrl_combo.setCurrentText(r.controller)
        form.addRow('Контроллер', self._ctrl_combo)

        self._fw_dir = QLineEdit(r.firmware_dir if r else '')
        self._fw_dir.setPlaceholderText('Папка на диске (от корня), напр. НГР/КПЧ/SMH5')
        fw_dir_row = QWidget()
        fw_dir_layout = QHBoxLayout(fw_dir_row)
        fw_dir_layout.setContentsMargins(0, 0, 0, 0)
        fw_dir_layout.setSpacing(4)
        fw_dir_layout.addWidget(self._fw_dir)
        _browse_fw = QPushButton('Обзор')
        _browse_fw.setObjectName('secondary')
        _browse_fw.setFixedHeight(30)
        _browse_fw.clicked.connect(self._browse_fw_dir)
        fw_dir_layout.addWidget(_browse_fw)
        form.addRow('Папка прошивки *', fw_dir_row)

        self._fw_type_combo = QComboBox()
        self._fw_type_combo.addItems(['plc', 'plc_hmi'])
        if r and r.firmware_type:
            self._fw_type_combo.setCurrentText(r.firmware_type)
        form.addRow('Тип прошивки', self._fw_type_combo)

        self._keywords = QLineEdit(', '.join(r.keywords) if r and r.keywords else '')
        self._keywords.setPlaceholderText('Ключевые слова через запятую')
        form.addRow('Ключевые слова', self._keywords)

        self._excl_kw = QLineEdit(', '.join(r.exclude_keywords) if r and r.exclude_keywords else '')
        self._excl_kw.setPlaceholderText('Исключить (через запятую)')
        form.addRow('Исключить слова', self._excl_kw)

        self._local_dir = QLineEdit(r.local_dir if r else '')
        self._local_dir.setPlaceholderText('Имя локальной папки (необязательно)')
        form.addRow('Локальная папка', self._local_dir)

        self._pch_list = QListWidget()
        self._pch_list.setSelectionMode(QAbstractItemView.MultiSelection)
        self._pch_list.setFixedHeight(80)
        self._upp_list = QListWidget()
        self._upp_list.setSelectionMode(QAbstractItemView.MultiSelection)
        self._upp_list.setFixedHeight(80)
        if self._db:
            rule_name = r.name if r else ''
            for t in self._db.get_all_templates():
                if t.template_type == 'pch':
                    item = QListWidgetItem(t.name)
                    item.setData(Qt.UserRole, t.id)
                    self._pch_list.addItem(item)
                    if rule_name and rule_name in t.rule_names:
                        item.setSelected(True)
                elif t.template_type == 'upp':
                    item = QListWidgetItem(t.name)
                    item.setData(Qt.UserRole, t.id)
                    self._upp_list.addItem(item)
                    if rule_name and rule_name in t.rule_names:
                        item.setSelected(True)
        form.addRow('Параметры ПЧ/КПЧ', self._pch_list)
        form.addRow('Параметры УПП', self._upp_list)

        self._io_map = MiniDropZone(r.io_map_path if r else '')
        form.addRow('Карта in/out', self._make_browse_row(
            self._io_map, file=True, folder=True))

        self._passport_dir = MiniDropZone(r.passport_dir if r else '')
        form.addRow('Паспорт (файл)', self._make_browse_row(
            self._passport_dir, file=True))

        self._instructions = MiniDropZone(r.instructions_path if r else '')
        form.addRow('Инструкции', self._make_browse_row(
            self._instructions, file=True, folder=True))

        self._notes_file = MiniDropZone(r.notes_file if r else '')
        form.addRow('Примечания (файл)', self._make_browse_row(
            self._notes_file, file=True))

        self._software_name = QLineEdit(r.software_name if r else '')
        self._software_name.setPlaceholderText('Название ПО для протокола')
        form.addRow('Название ПО', self._software_name)

        scroll.setWidget(form_widget)
        layout.addWidget(scroll)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _make_browse_row(self, line_edit: 'MiniDropZone',
                          file: bool = False, folder: bool = False) -> QWidget:
        """MiniDropZone слева (растягивается) + кнопки «×», «Файл»/«Папка» справа."""
        wrapper = QWidget()
        hlay = QHBoxLayout(wrapper)
        hlay.setContentsMargins(0, 0, 0, 0)
        hlay.setSpacing(6)
        hlay.addWidget(line_edit, 1)

        clr = QPushButton('× Удалить')
        clr.setObjectName('secondary')
        clr.setToolTip('Очистить путь — нажмите OK чтобы сохранить')
        clr.clicked.connect(lambda *_, le=line_edit: le.set_path(''))
        hlay.addWidget(clr)

        if file:
            btn = QPushButton('Файл')
            btn.setObjectName('secondary')
            btn.clicked.connect(lambda *_, le=line_edit: self._browse_file_into(le))
            hlay.addWidget(btn)
        if folder:
            btn = QPushButton('Папка')
            btn.setObjectName('secondary')
            btn.clicked.connect(lambda *_, le=line_edit: self._browse_folder_into(le))
            hlay.addWidget(btn)

        return wrapper

    def _browse_file_into(self, le: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(self, 'Выберите файл', '', 'Все файлы (*.*)')
        if path:
            le.setText(path)

    def _browse_folder_into(self, le: QLineEdit):
        path = QFileDialog.getExistingDirectory(self, 'Выберите папку', '')
        if path:
            le.setText(path)

    def _rel_or_abs(self, path: str, root: str) -> str:
        """Used only for firmware_dir (relative to WebDAV root)."""
        if root:
            try:
                return os.path.relpath(path, root)
            except ValueError:
                pass
        return path

    def _browse_fw_dir(self):
        """Browse for firmware_dir — stored relative to root_path."""
        root = self._cfg.root_path()
        path = QFileDialog.getExistingDirectory(self, 'Выберите папку прошивки', root or '')
        if path:
            self._fw_dir.setText(self._rel_or_abs(path, root))

    def save_template_links(self, rule_name: str, db):
        """Update pch/upp template rule_names based on current list selection."""
        from dataclasses import replace as dc_replace
        selected_pch_ids = {
            self._pch_list.item(i).data(Qt.UserRole)
            for i in range(self._pch_list.count())
            if self._pch_list.item(i).isSelected()
        }
        selected_upp_ids = {
            self._upp_list.item(i).data(Qt.UserRole)
            for i in range(self._upp_list.count())
            if self._upp_list.item(i).isSelected()
        }
        for t in db.get_all_templates():
            if t.template_type not in ('pch', 'upp'):
                continue
            sel_ids = selected_pch_ids if t.template_type == 'pch' else selected_upp_ids
            names = list(t.rule_names)
            changed = False
            if t.id in sel_ids and rule_name not in names:
                names.append(rule_name)
                changed = True
            elif t.id not in sel_ids and rule_name in names:
                names.remove(rule_name)
                changed = True
            if changed:
                db.upsert_template(dc_replace(t, rule_names=names))

    def _validate_and_accept(self):
        if not self._name.text().strip():
            QMessageBox.warning(self, 'Ошибка', 'Укажите название правила.')
            return
        if not self._fw_dir.text().strip():
            QMessageBox.warning(self, 'Ошибка', 'Укажите папку прошивки.')
            return
        self.accept()

    def _split_kw(self, text: str) -> list[str]:
        return [w.strip() for w in text.split(',') if w.strip()]

    def get_rule(self) -> Rule:
        r = self._rule
        return Rule(
            id               = r.id if r else None,
            name             = self._name.text().strip(),
            equipment_type   = self._eq_combo.currentText().strip(),
            work_type        = ', '.join(
                self._work_list.item(i).text()
                for i in range(self._work_list.count())
                if self._work_list.item(i).isSelected()
            ),
            controller       = self._ctrl_combo.currentText().strip(),
            firmware_dir     = self._fw_dir.text().strip(),
            firmware_type    = self._fw_type_combo.currentText(),
            software_name    = self._software_name.text().strip(),
            keywords         = self._split_kw(self._keywords.text()),
            exclude_keywords = self._split_kw(self._excl_kw.text()),
            kw_mode          = 'any',
            local_dir        = self._local_dir.text().strip(),
            local_synced     = r.local_synced if r else False,
            disk_snapshot    = r.disk_snapshot if r else {},
            param_pch_dir    = '',
            param_upp_dir    = '',
            io_map_path      = self._io_map.text().strip(),
            passport_dir     = self._passport_dir.text().strip(),
            instructions_path = self._instructions.text().strip(),
            notes_file       = self._notes_file.text().strip(),
            created_at       = r.created_at if r else datetime.now(),
            updated_at       = datetime.now(),
        )
