"""
FirmwareFinder — SQLite Database
===================================
Single-file SQLite store for all persistent data.
Schema: rules, versions, templates, sync_queue.
"""

import sqlite3
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from app.domain.models import (
    Rule, FirmwareVersion, Template, SyncQueueItem, Version
)

_ISO = '%Y-%m-%d %H:%M:%S'


def _now() -> str:
    return datetime.now().strftime(_ISO)


def _dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.strptime(s, _ISO)
    except Exception:
        return None


class Database:
    """Thread-safe SQLite wrapper with schema migrations."""

    def __init__(self, db_path: str):
        self._path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('PRAGMA foreign_keys=ON')
        self._migrate()

    # ── Schema ────────────────────────────────────────────────────────────────

    def _migrate(self):
        cur = self._conn.cursor()
        cur.executescript("""
        CREATE TABLE IF NOT EXISTS rules (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            name              TEXT    UNIQUE NOT NULL,
            equipment_type    TEXT    NOT NULL DEFAULT '',
            work_type         TEXT    NOT NULL DEFAULT '',
            controller        TEXT    NOT NULL DEFAULT '',
            firmware_dir      TEXT    NOT NULL DEFAULT '',
            firmware_type     TEXT    NOT NULL DEFAULT 'plc',
            software_name     TEXT    NOT NULL DEFAULT '',
            keywords          TEXT    NOT NULL DEFAULT '[]',
            exclude_keywords  TEXT    NOT NULL DEFAULT '[]',
            kw_mode           TEXT    NOT NULL DEFAULT 'all',
            local_dir         TEXT    NOT NULL DEFAULT '',
            local_synced      INTEGER NOT NULL DEFAULT 0,
            disk_snapshot     TEXT    NOT NULL DEFAULT '{}',
            param_pch_dir     TEXT    NOT NULL DEFAULT '',
            param_upp_dir     TEXT    NOT NULL DEFAULT '',
            passport_dir      TEXT    NOT NULL DEFAULT '',
            io_map_path       TEXT    NOT NULL DEFAULT '',
            instructions_path TEXT    NOT NULL DEFAULT '',
            notes_file        TEXT    NOT NULL DEFAULT '',
            created_at        TEXT    NOT NULL,
            updated_at        TEXT    NOT NULL
        );

        CREATE TABLE IF NOT EXISTS versions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_names  TEXT    NOT NULL DEFAULT '[]',
            version     TEXT    NOT NULL,
            filename    TEXT    NOT NULL DEFAULT '',
            local_path  TEXT    NOT NULL DEFAULT '',
            disk_path   TEXT    NOT NULL DEFAULT '',
            controller  TEXT    NOT NULL DEFAULT '',
            device_type TEXT    NOT NULL DEFAULT '',
            work_type   TEXT    NOT NULL DEFAULT '',
            extension   TEXT    NOT NULL DEFAULT '',
            description TEXT    NOT NULL DEFAULT '',
            changelog   TEXT    NOT NULL DEFAULT '',
            upload_date TEXT    NOT NULL,
            archived    INTEGER NOT NULL DEFAULT 0,
            io_map_path    TEXT NOT NULL DEFAULT '',
            param_pch_dir  TEXT NOT NULL DEFAULT '',
            param_upp_dir  TEXT NOT NULL DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS templates (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT    UNIQUE NOT NULL,
            template_type TEXT    NOT NULL DEFAULT 'upp',
            path          TEXT    NOT NULL DEFAULT '',
            description   TEXT    NOT NULL DEFAULT '',
            rule_names    TEXT    NOT NULL DEFAULT '[]'
        );

        CREATE TABLE IF NOT EXISTS sync_queue (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            action     TEXT    NOT NULL,
            payload    TEXT    NOT NULL DEFAULT '{}',
            created_at TEXT    NOT NULL,
            synced_at  TEXT,
            status     TEXT    NOT NULL DEFAULT 'pending',
            error      TEXT    NOT NULL DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );
        """)
        self._conn.commit()

    # ── Settings ──────────────────────────────────────────────────────────────

    def get_setting(self, key: str, default: str = '') -> str:
        row = self._conn.execute(
            'SELECT value FROM settings WHERE key=?', (key,)
        ).fetchone()
        return row['value'] if row else default

    def set_setting(self, key: str, value: str):
        self._conn.execute(
            'INSERT INTO settings(key,value) VALUES(?,?) '
            'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
            (key, value)
        )
        self._conn.commit()

    # ── Rules ─────────────────────────────────────────────────────────────────

    def upsert_rule(self, rule: Rule) -> int:
        now = _now()
        cur = self._conn.execute(
            """INSERT INTO rules
               (name,equipment_type,work_type,controller,firmware_dir,firmware_type,
                software_name,keywords,exclude_keywords,kw_mode,local_dir,local_synced,
                disk_snapshot,param_pch_dir,param_upp_dir,passport_dir,io_map_path,
                instructions_path,notes_file,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(name) DO UPDATE SET
                 equipment_type=excluded.equipment_type,
                 work_type=excluded.work_type,
                 controller=excluded.controller,
                 firmware_dir=excluded.firmware_dir,
                 firmware_type=excluded.firmware_type,
                 software_name=excluded.software_name,
                 keywords=excluded.keywords,
                 exclude_keywords=excluded.exclude_keywords,
                 kw_mode=excluded.kw_mode,
                 local_dir=excluded.local_dir,
                 local_synced=excluded.local_synced,
                 disk_snapshot=excluded.disk_snapshot,
                 param_pch_dir=excluded.param_pch_dir,
                 param_upp_dir=excluded.param_upp_dir,
                 passport_dir=excluded.passport_dir,
                 io_map_path=excluded.io_map_path,
                 instructions_path=excluded.instructions_path,
                 notes_file=excluded.notes_file,
                 updated_at=excluded.updated_at
            """,
            (rule.name, rule.equipment_type, rule.work_type, rule.controller,
             rule.firmware_dir, rule.firmware_type, rule.software_name,
             json.dumps(rule.keywords, ensure_ascii=False),
             json.dumps(rule.exclude_keywords, ensure_ascii=False),
             rule.kw_mode, rule.local_dir, int(rule.local_synced),
             json.dumps(rule.disk_snapshot, ensure_ascii=False),
             rule.param_pch_dir, rule.param_upp_dir, rule.passport_dir,
             rule.io_map_path, rule.instructions_path, rule.notes_file,
             now, now)
        )
        self._conn.commit()
        if rule.id:
            return rule.id
        row = self._conn.execute(
            'SELECT id FROM rules WHERE name=?', (rule.name,)
        ).fetchone()
        return row['id'] if row else -1

    def get_rule(self, name: str) -> Optional[Rule]:
        row = self._conn.execute(
            'SELECT * FROM rules WHERE name=?', (name,)
        ).fetchone()
        return self._row_to_rule(row) if row else None

    def get_all_rules(self) -> list[Rule]:
        rows = self._conn.execute('SELECT * FROM rules ORDER BY name').fetchall()
        return [self._row_to_rule(r) for r in rows]

    def delete_rule(self, rule_id: int):
        self._conn.execute('DELETE FROM rules WHERE id=?', (rule_id,))
        self._conn.commit()

    def _row_to_rule(self, row: sqlite3.Row) -> Rule:
        return Rule(
            id=row['id'],
            name=row['name'],
            equipment_type=row['equipment_type'],
            work_type=row['work_type'],
            controller=row['controller'],
            firmware_dir=row['firmware_dir'],
            firmware_type=row['firmware_type'],
            software_name=row['software_name'],
            keywords=json.loads(row['keywords'] or '[]'),
            exclude_keywords=json.loads(row['exclude_keywords'] or '[]'),
            kw_mode=row['kw_mode'],
            local_dir=row['local_dir'],
            local_synced=bool(row['local_synced']),
            disk_snapshot=json.loads(row['disk_snapshot'] or '{}'),
            param_pch_dir=row['param_pch_dir'],
            param_upp_dir=row['param_upp_dir'],
            passport_dir=row['passport_dir'],
            io_map_path=row['io_map_path'],
            instructions_path=row['instructions_path'],
            notes_file=row['notes_file'],
            created_at=_dt(row['created_at']) or datetime.now(),
            updated_at=_dt(row['updated_at']) or datetime.now(),
        )

    # ── Versions ──────────────────────────────────────────────────────────────

    def add_version(self, fv: FirmwareVersion) -> int:
        cur = self._conn.execute(
            """INSERT INTO versions
               (rule_names,version,filename,local_path,disk_path,controller,
                device_type,work_type,extension,description,changelog,
                upload_date,archived,io_map_path,param_pch_dir,param_upp_dir)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (json.dumps(fv.rule_names, ensure_ascii=False),
             str(fv.version),
             fv.filename, fv.local_path, fv.disk_path,
             fv.controller, fv.device_type, fv.work_type, fv.extension,
             fv.description, fv.changelog,
             fv.upload_date.strftime(_ISO),
             int(fv.archived),
             fv.io_map_path, fv.param_pch_dir, fv.param_upp_dir)
        )
        self._conn.commit()
        return cur.lastrowid

    def get_versions_for_rule(self, rule_name: str,
                              include_archived: bool = False) -> list[FirmwareVersion]:
        rows = self._conn.execute(
            'SELECT * FROM versions ORDER BY upload_date DESC'
        ).fetchall()
        result = []
        for row in rows:
            names = json.loads(row['rule_names'] or '[]')
            if rule_name in names:
                if not include_archived and row['archived']:
                    continue
                fv = self._row_to_version(row)
                if fv:
                    result.append(fv)
        return result

    def get_latest_version(self, rule_name: str) -> Optional[FirmwareVersion]:
        versions = self.get_versions_for_rule(rule_name, include_archived=False)
        if not versions:
            return None
        # Sort by Version object
        def _key(fv: FirmwareVersion):
            v = Version.parse(str(fv.version))
            return v if v else Version(raw='', prefix=0, body=(0,), date=0)
        return max(versions, key=_key)

    def archive_version(self, version_id: int):
        self._conn.execute(
            'UPDATE versions SET archived=1 WHERE id=?', (version_id,)
        )
        self._conn.commit()

    def restore_version(self, version_id: int):
        self._conn.execute(
            'UPDATE versions SET archived=0 WHERE id=?', (version_id,)
        )
        self._conn.commit()

    def delete_version(self, version_id: int):
        self._conn.execute('DELETE FROM versions WHERE id=?', (version_id,))
        self._conn.commit()

    def get_all_versions(self) -> list[FirmwareVersion]:
        rows = self._conn.execute(
            'SELECT * FROM versions ORDER BY upload_date DESC'
        ).fetchall()
        return [v for r in rows if (v := self._row_to_version(r))]

    def _row_to_version(self, row: sqlite3.Row) -> Optional[FirmwareVersion]:
        ver = Version.parse(row['version'])
        if not ver:
            ver = Version(raw=row['version'], prefix=0, body=(0,), date=0)
        return FirmwareVersion(
            id=row['id'],
            rule_ids=[],
            rule_names=json.loads(row['rule_names'] or '[]'),
            version=ver,
            filename=row['filename'],
            local_path=row['local_path'],
            disk_path=row['disk_path'],
            controller=row['controller'],
            device_type=row['device_type'],
            work_type=row['work_type'],
            extension=row['extension'],
            description=row['description'],
            changelog=row['changelog'],
            upload_date=_dt(row['upload_date']) or datetime.now(),
            archived=bool(row['archived']),
            io_map_path=row['io_map_path'],
            param_pch_dir=row['param_pch_dir'],
            param_upp_dir=row['param_upp_dir'],
        )

    # ── Templates ─────────────────────────────────────────────────────────────

    def upsert_template(self, t: Template) -> int:
        self._conn.execute(
            """INSERT INTO templates(name,template_type,path,description,rule_names)
               VALUES(?,?,?,?,?)
               ON CONFLICT(name) DO UPDATE SET
                 template_type=excluded.template_type,
                 path=excluded.path,
                 description=excluded.description,
                 rule_names=excluded.rule_names
            """,
            (t.name, t.template_type, t.path, t.description,
             json.dumps(t.rule_names, ensure_ascii=False))
        )
        self._conn.commit()
        row = self._conn.execute(
            'SELECT id FROM templates WHERE name=?', (t.name,)
        ).fetchone()
        return row['id'] if row else -1

    def get_all_templates(self) -> list[Template]:
        rows = self._conn.execute(
            'SELECT * FROM templates ORDER BY name'
        ).fetchall()
        return [Template(
            id=r['id'], name=r['name'], template_type=r['template_type'],
            path=r['path'], description=r['description'],
            rule_names=json.loads(r['rule_names'] or '[]')
        ) for r in rows]

    def delete_template(self, template_id: int):
        self._conn.execute('DELETE FROM templates WHERE id=?', (template_id,))
        self._conn.commit()

    # ── Sync Queue ────────────────────────────────────────────────────────────

    def enqueue(self, action: str, payload: dict) -> int:
        cur = self._conn.execute(
            """INSERT INTO sync_queue(action,payload,created_at,status)
               VALUES(?,?,?,'pending')
            """,
            (action, json.dumps(payload, ensure_ascii=False), _now())
        )
        self._conn.commit()
        return cur.lastrowid

    def get_pending(self) -> list[SyncQueueItem]:
        rows = self._conn.execute(
            "SELECT * FROM sync_queue WHERE status='pending' ORDER BY created_at"
        ).fetchall()
        return [self._row_to_queue(r) for r in rows]

    def mark_synced(self, item_id: int):
        self._conn.execute(
            "UPDATE sync_queue SET status='synced', synced_at=? WHERE id=?",
            (_now(), item_id)
        )
        self._conn.commit()

    def mark_failed(self, item_id: int, error: str):
        self._conn.execute(
            "UPDATE sync_queue SET status='failed', error=? WHERE id=?",
            (error, item_id)
        )
        self._conn.commit()

    def _row_to_queue(self, row: sqlite3.Row) -> SyncQueueItem:
        return SyncQueueItem(
            id=row['id'],
            action=row['action'],
            payload=json.loads(row['payload'] or '{}'),
            created_at=_dt(row['created_at']) or datetime.now(),
            synced_at=_dt(row['synced_at']),
            status=row['status'],
            error=row['error'],
        )

    def close(self):
        self._conn.close()
